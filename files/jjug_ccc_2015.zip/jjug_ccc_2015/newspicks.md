- monji さん
- UZABASE 
    - 会社
    - サービス
        - SPEEDA
            - 経済情報の Google みたいなサービス
            - 裏は java
        - NewsPicks
            - 一般向けの経済情報のまとめ
- 経済情報の情報収集用サービス
- プッシュするニュースは、人力で探し出して、 line で話し合って通知している
- NewsPicks の裏側
    - Web 版とモバイル版
    - EC2 上で提供
    - AWS を活用している
    - DB は 4 種類使っている
        - RDS : Master
        - Dynamo DB : Transaction
        - ElastiCache : Time line 
        - Redshift : Access log
        - 用途によって使い分けている
    - アプリサーバー・バッチサーバー・連携の入り口を Java で書いている
    - なぜ java?
        - もともとのサービスが java で書かれていたから
        - java はシンプルでだれでも使えて、簡単に使えるから
        - ruby or scara
            - ruby : 大規模の時は動的片付けがつらい
            - scara : コンパイルが遅くてつらい
    - アプリサーバーの内側
        - NGiNX と Tomcat fluentd
        - RESt Api : java 8 + lombok + spring
        - json の Bean 定義が面倒
            - lombok を使うと簡単にできる
            - デレミュート？
            - Extention メソッドと使いだすと、 IDE との統合が微妙
            - SI 案件で使うのは怖かったけど、使ってみると不具合とかは怒ってない
        - Spring
            - Spring しんどい
            - でかい
            - JAX-RS + Guice / Dagger がおすすめ
        - SQS (Simple Queue Service)
            - 分散キュー
            - コンシューマは冪等に実装する必要がある
- 急成長を支える技術
    - Redis のを ElastiCache に分割
    - ユーザー数10万人ずつくらいで分割
    - ユーザーで分割すると、人気ユーザーに負荷が集中した
    - ハッシュで分散させた
    - キャッシュ用の Redis を分散
        - 書き込みと読み込み用の ElastiCache に分散
        - 読み込み用は、書き込み用をレプリケーションして、落ちたときのためにフェールオーバーできるようにした
    - SEO 対策
        - Angular で作られていたため、 google にインデックスされない
        - phantom で返すようにした
        - phantom は荒ぶる
    - API の後方互換性
        - コードはくそだが、スタートアップは生きるか死ぬか
    - KPI のダッシュボード
        - ログを可視化して KPI 化
        - Spring Boot
            - 1週間ですぐ作る、とかだと適している
        - SQL2O
            - O/R Mapper
    - Polyfill Service
        - ユーザーエージェントによって、 polyfill が落ちてくるサービス
        - 古いブラウザでも、モダンな実装ができるようになる
    - HANDLEBARS
        - 初期表示は html で、以後は ajax で json をやりとり
        - 








